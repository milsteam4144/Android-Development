package com.example.milsteam4144.m1t1_gq_milstead;

public class Question {

    private int mTextResId; //initialize field see below
    private boolean mAnswerTrue; //initialize field this can only be changed by setter functions
    //because it is private, only methods in the Question class can access it

    //Create constructor
    public Question(int textResId, boolean answerTrue){
        mTextResId = textResId;
        mAnswerTrue = answerTrue;
    }

    //Create getters and setters for the fields
    public int getTextResId() {
        return mTextResId;
    }

    public void setTextResId(int textResId) {
        mTextResId = textResId;
    }

    public boolean isAnswerTrue() {
        return mAnswerTrue;
    }

    public void setAnswerTrue(boolean answerTrue) {
        mAnswerTrue = answerTrue;
    }


}
