//Mallory Milstead
//9/4/2018
//WEB 251
//M1T1 Challenge- Define gravity of toast


package com.example.milsteam4144.m1t1_gq_milstead;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class QuizActivity extends AppCompatActivity {

    //Initialize fields
    private Button mTrueButton;
    private Button mFalseButton;
    private Button mNextButton;
    private Button mPrevButton;
    private TextView mQuestionTextView;
    private int mCurrentIndex = 0; //Create a field for the index of the array of question objects


    //Create a new array object and initialize it with the Question objects
    private Question[] mQuestionBank = new Question[] {
            new Question(R.string.question_australia, true),
            new Question(R.string.question_oceans, true),
            new Question(R.string.question_mideast, false),
            new Question(R.string.question_africa, false),
            new Question(R.string.question_americas, true),
            new Question(R.string.question_asia, true),
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        //Display questions
        mQuestionTextView = (TextView) findViewById(R.id.question_text_view); //assign the resource with the id=question_text_view to a field
        mQuestionTextView.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = (mCurrentIndex + 1) % mQuestionBank.length; //increment the current index
                updateQuestion(); //Call a function to update the question
                }
            });


        //assign clickListner to the TrueButton
        mTrueButton = (Button) findViewById(R.id.true_button); //assign the id of the true button to a field
        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               checkAnswer(true);
            }
        });

        //assign clickListner to the FalseButton
        mFalseButton = (Button) findViewById(R.id.false_button); //assign the id of the false button to a field
        mFalseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               checkAnswer(false);
            }
        });

        //assign clickListner to the NextButton
        mNextButton = (Button) findViewById(R.id.next_button); //assign the id of the next button to a field
        mNextButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = (mCurrentIndex + 1) % mQuestionBank.length; //increment the current index
               updateQuestion(); //Call a function to update the question
            }
        });

        //assign clickListner to the PrevButton
        mPrevButton = (Button) findViewById(R.id.prev_button); //assign the id of the next button to a field
        mPrevButton.setOnClickListener(
                new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = mCurrentIndex -1; //decrement the current index
                if (mCurrentIndex -1 < 0) { //If the current index -1 is less than 0
                    mCurrentIndex = mQuestionBank.length - 1;}//Reset the current index to 5 (the end of the list
                    updateQuestion(); //Call a function to update the question
            }
        }
        );

        updateQuestion(); //Call the function to initially set the text in the activity view


    }

    //Create a function to update the question
    private void updateQuestion(){
        int question = mQuestionBank[mCurrentIndex].getTextResId();
        mQuestionTextView.setText(question);
    }

    private void checkAnswer(boolean userPressedTrue){
        boolean answerIsTrue = mQuestionBank[mCurrentIndex].isAnswerTrue();

        int messageResId = 0; //initialize variable ................

        if (userPressedTrue == answerIsTrue){
            messageResId = R.string.correct_toast;
        } else{
            messageResId = R.string.incorrect_toast;
        }
        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show();
    }
}
