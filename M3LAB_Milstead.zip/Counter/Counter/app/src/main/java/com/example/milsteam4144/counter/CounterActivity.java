//Mallory Milstead
//10/2/2018
//App increments when button is pressed. Use location orientation and save variable to Bundle


package com.example.milsteam4144.counter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log; //This allows for running LOG and seeing Logcat messages
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CounterActivity extends AppCompatActivity {

    // TAG is used as a debugging identifier
    private static final String TAG = "CounterActivity";
    //This constant is the key for the key-value pair that will be stored in the Bundle
    private static final String KEY_COUNTER = "counter";

    // model
    int counterValue;

    // controls
    TextView counterText;
    Button incrementButton;
    Button resetButton;

    //Override methods to display events in Logcat
    @Override
    public void onStart()
    {
        super.onStart();
        Log.d(TAG, "onStart() called");
    }

    @Override
    public void onResume()
    {
        super.onResume();
        Log.d(TAG, "onResume() called");
    }

    @Override
    public void onPause()
    {
        super.onPause();
        Log.d(TAG, "onPause() called");
    }

    @Override
    public void onStop()
    {
        super.onStop();
        Log.d(TAG, "onStop() called");
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();
        Log.d(TAG, "onDestroy() called");
    }

    //Overriding the onSaveInstanceState(Bundle) to write the value of counterValue to the
    //Bundle with the constant as its key
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState)
    {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt(KEY_COUNTER, counterValue); //arguments are String key (from above) and Int value
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counter);
        Log.d(TAG, "onCreate() called" ); //Logcat message

        if (savedInstanceState != null)
        {
            counterValue = savedInstanceState.getInt(KEY_COUNTER, 0);
        }
        // setup
            else
            {
            counterValue = 0;
            }

        // set up the counter value at start
        counterText = (TextView) findViewById(R.id.text_counter);
        // String.valueOf() converts the int into a string
        updateCounter();

        // set button event handlers
        incrementButton = (Button) findViewById(R.id.button_increment);
        resetButton = (Button) findViewById(R.id.button_reset);

        incrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // increase by 1 per click
                counterValue++;
                updateCounter();
                Log.d(TAG, "counter increment");
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counterValue = 0;
                updateCounter();
                Log.d(TAG, "counter display reset");
            }
        });



    }

    void updateCounter()
    {
        //set the counter text view to the current value
        String counterString = String.valueOf(counterValue);
        counterText.setText(counterString);
    }
}


